--WarEffortData = {}

local currentGossipIndex = {}
currentGossipIndex["horde"] = 2
currentGossipIndex["alliance"] = 2
local realmName = GetRealmName()


-- Helper
local function getFactionAndItemNamesFromText(text)
	-- Horde text
	if string.match(text, "How many metal bars you say?") then
		return "horde", "current_copper_bar", "total_copper_bar", "current_tin_bar", "total_tin_bar", "total_mithril_bar", "current_mithril_bar"
	elseif string.match(text, "Last I heard the Horde") then
		return "horde", "current_peacebloom", "total_peacebloom", "current_firebloom", "total_firebloom", "current_purple_lotus", "total_purple_lotus"
	elseif string.match(text, "Leather skins?") then
		return "horde", "total_heavy_leather", "current_heavy_leather", "current_thick_leather", "total_thick_leather", "current_rugged_leather", "total_rugged_leather"
	elseif string.match(text, "The Horde is stockpiling") then
		return "horde", "current_wool_bandage", "total_wool_bandage", "current_mageweave_bandage", "total_mageweave_bandage", "current_runecloth_bandage", "total_runecloth_bandage"
	elseif string.match(text, "You want to know about ration collections?") then
		return "horde", "current_lean_wolf_steak", "total_lean_wolf_steak", "current_yellowtail", "total_yellowtail", "current_baked_salmon", "total_baked_salmon"
		
	-- Alliance text
	elseif string.match(text, "Last I was informed; we have") then
		return "alliance", "current_copper_bar", "total_copper_bar", "current_iron_bar", "total_iron_bar", "current_thorium_bar", "total_thorium_bar"
	elseif string.match(text, "Herbs, herbs,") then
		return "alliance", "current_stranglekelp", "total_stranglekelp", "current_purple_lotus", "total_purple_lotus", "current_arthas_tears", "total_arthas_tears"
	elseif string.match(text, "I received an update on that") then
		return "alliance", "total_light_leather", "current_light_leather", "current_medium_leather", "total_medium_leather", "current_thick_leather", "total_thick_leather"
	elseif string.match(text, "Collection of bandages") then
		return "alliance", "current_linen_bandage", "total_linen_bandage", "current_silk_bandage", "total_silk_bandage", "current_runecloth_bandage", "total_runecloth_bandage"
	elseif string.match(text, "On the cooked goods") then
		return "alliance", "current_rainbow_fin", "total_rainbow_fin", "current_roast_raptor", "total_roast_raptor", "current_spotted_yellowtail", "total_spotted_yellowtail"
	end
end

local function getFactionFromGossip(text)
	if string.match(text, "Lok'tar") then
		return "horde"
	elseif string.match(text, "I am Field Marshal") then
		return "alliance"
	end
end

local function eventHandler(self, event, ...)
	local optCount = GetNumGossipOptions()
	local text = GetGossipText()
	
	-- Start dialog, move through each option from here
	if optCount == 6 then
		local faction = getFactionFromGossip(text)
		if currentGossipIndex[faction] <= 6 then
			print("Gossip: " .. currentGossipIndex[faction] .. "/6")
			SelectGossipOption(currentGossipIndex[faction])
			currentGossipIndex[faction] = currentGossipIndex[faction] + 1
		else
			print("Data collection done!")
		end
	else
		WarEffortData = WarEffortData or {}
		WarEffortData[realmName] = WarEffortData[realmName] or {}

		-- Check if the war effort is complete, if so just clear out the data, we'll handle it later during processing
		if string.match(text, "Unexpected that you are all") or string.match(text, "We've done it,") then
			WarEffortData[realmName] = {}
		else
			-- We have 1 gossip option, grab the text and move back to main
			local a, b, c, d, e, f = string.match(text, "(%d+)[%a%p%s]*(%d+)[%a%p%s]*(%d+)[%a%p%s]*(%d+)[%a%p%s]*(%d+)[%a%p%s]*(%d+)")	
			local faction, l1, l2, l3, l4, l5, l6 = getFactionAndItemNamesFromText(text)

			SelectGossipOption(1)
			
			if faction then
				local factionCounts = WarEffortData[realmName]
				factionCounts[faction] = factionCounts[faction] or {}
				factionCounts[faction][l1] = a
				factionCounts[faction][l2] = b
				factionCounts[faction][l3] = c
				factionCounts[faction][l4] = d
				factionCounts[faction][l5] = e
				factionCounts[faction][l6] = f
			end
		end
	end
end

local frame = CreateFrame("FRAME", "foo");
frame:RegisterEvent("GOSSIP_SHOW")
frame:SetScript("OnEvent", eventHandler)
