Notes on this addon:

* The intention of this addon is to collect all region server data for the War Effort. It does this by collecting
  NPC text from the 2 Ironforge NPCs (Field Marshall Snowfall and General Zog). This needs to be an english client,
  I don't know if this works in Orgrimmar or not.
* This addon was designed to merge the all of server data itself, so 1 account with multiple alts created
  on each server that all periodically gather the data is needed. Myself, I created a bunch of dwarf characters
  and ran them to Ironforge - I periodically log into all of them to update the data.
* This is a quick-and-dirty approach that may auto talk to NPCs, I would suggest only enabling it for alts
* Servers that have completed the war effort can be skipped

There is no client that uploads the data, therefore you'll need to supply the .lua file manually to drivehappy@gmail.com.

After the addon is installed, the lua file can be found on your system at:
  %WoWInstallPath%/_classic/WTF/Account/%YourAccountName%/SavedVariables/DrivehappyWarEffort.lua

Please note that I already gather the US region server data, other regions are welcome - but _only_ if a large number of
servers are collected from the single account. I don't handle data persistence/merging on my side, so all of the server
data needs to be present.
